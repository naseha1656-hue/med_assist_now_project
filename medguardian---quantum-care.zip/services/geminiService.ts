import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY is not defined");
  }
  return new GoogleGenAI({ apiKey });
};

export const streamDrAIResponse = async function* (
  history: { role: string; text: string }[],
  newMessage: string
) {
  try {
    const ai = getClient();
    
    // Transform history to Gemini format if needed, though for single-turn simply sending the message is often enough.
    // However, to maintain context, we use a chat session.
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: `You are Dr. AI, a helpful, empathetic, and professional medical assistant for MedGuardian. 
        Your goal is to provide preliminary medical information, guide users to the correct portal (User, Driver, or Pharmacy), and answer health-related queries.
        
        IMPORTANT DISCLAIMER: You must always state that you are an AI and not a real doctor. Advise users to consult a professional for serious concerns.
        
        Keep responses concise, reassuring, and easy to understand.
        `,
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }))
    });

    const result = await chat.sendMessageStream({ message: newMessage });

    for await (const chunk of result) {
       yield chunk.text;
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield "I'm having trouble connecting to the medical database right now. Please try again later.";
  }
};