import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/Landing';
import { PortalLayout } from './pages/PortalLayout';

// Placeholder components for portals
const UserDashboard = () => (
    <div className="space-y-6">
        <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
            <h3 className="text-lg font-bold text-brand-dark mb-2">Welcome back, John</h3>
            <p className="text-gray-600">You have <span className="font-bold text-brand-primary">2 active prescriptions</span> awaiting refill.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 border border-gray-100 rounded-2xl hover:border-blue-200 transition-colors cursor-pointer">
                <h4 className="font-bold text-gray-800">Order Medicine</h4>
                <p className="text-sm text-gray-500 mt-1">Browse catalog and upload prescriptions</p>
            </div>
            <div className="p-6 border border-gray-100 rounded-2xl hover:border-blue-200 transition-colors cursor-pointer">
                <h4 className="font-bold text-gray-800">My Appointments</h4>
                <p className="text-sm text-gray-500 mt-1">Schedule video consult with Dr. AI</p>
            </div>
        </div>
    </div>
);

const DriverDashboard = () => (
    <div className="space-y-6">
        <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
            <h3 className="text-lg font-bold text-green-900 mb-2">Route Status: Active</h3>
            <p className="text-gray-600">Next delivery is <span className="font-bold text-green-700">5 mins away</span>.</p>
        </div>
        <div className="h-64 bg-gray-100 rounded-2xl flex items-center justify-center text-gray-400">
            Map Visualization Placeholder
        </div>
    </div>
);

const PharmacyDashboard = () => (
    <div className="space-y-6">
        <div className="flex gap-4 mb-6">
            <div className="flex-1 bg-white p-4 rounded-xl shadow-sm border border-gray-100 text-center">
                <div className="text-2xl font-bold text-brand-primary">124</div>
                <div className="text-xs text-gray-500 uppercase tracking-wide">Pending Orders</div>
            </div>
            <div className="flex-1 bg-white p-4 rounded-xl shadow-sm border border-gray-100 text-center">
                <div className="text-2xl font-bold text-red-500">3</div>
                <div className="text-xs text-gray-500 uppercase tracking-wide">Critical Stock</div>
            </div>
        </div>
        <div className="p-4 border border-gray-100 rounded-2xl">
            <h4 className="font-bold text-gray-800 mb-4">Recent Prescriptions</h4>
            <div className="space-y-3">
                {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-700">RX-{202400 + i}</span>
                        <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Processing</span>
                    </div>
                ))}
            </div>
        </div>
    </div>
);

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        
        {/* Portal Routes wrapped in layout */}
        <Route element={<PortalLayout />}>
          <Route path="/user" element={<UserDashboard />} />
          <Route path="/driver" element={<DriverDashboard />} />
          <Route path="/pharmacy" element={<PharmacyDashboard />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default App;