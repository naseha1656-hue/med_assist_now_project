export enum PortalType {
  USER = 'user',
  DRIVER = 'driver',
  PHARMACY = 'pharmacy'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface PortalConfig {
  id: PortalType;
  title: string;
  description: string;
  icon: React.ReactNode;
  path: string;
}