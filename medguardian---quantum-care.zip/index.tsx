// React application removed. 
// The application is now fully implemented in index.html using Vanilla JavaScript and HTML.