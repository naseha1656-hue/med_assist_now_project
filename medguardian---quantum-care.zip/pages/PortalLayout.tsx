import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { Header } from '../components/Header';
import { DrAIChat } from '../components/DrAIChat';

export const PortalLayout: React.FC = () => {
  const location = useLocation();
  
  // Extract portal name from path
  const portalName = location.pathname.split('/')[1]?.toUpperCase();

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex items-center gap-4">
          <Link to="/" className="p-2 hover:bg-white rounded-full transition-colors text-gray-500 hover:text-brand-primary">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <div className="h-8 w-px bg-gray-300"></div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">{portalName} PORTAL</h1>
        </div>
        <div className="bg-white rounded-3xl p-8 min-h-[60vh] border border-gray-100 shadow-sm relative overflow-hidden">
            {/* Background Mist inside portal card */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-50/50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
            <Outlet />
        </div>
      </div>
      <DrAIChat />
    </div>
  );
};