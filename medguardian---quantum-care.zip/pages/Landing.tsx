import React from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Truck, Store, ArrowRight, Activity } from 'lucide-react';
import { Header } from '../components/Header';
import { Button } from '../components/Button';
import { DrAIChat } from '../components/DrAIChat';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  const portals = [
    {
      id: 'user',
      title: 'User Portal',
      description: 'Order medicines, consult doctors, and track your health history.',
      icon: <User className="w-8 h-8 text-brand-primary" />,
      path: '/user',
      buttonText: 'Access Patient Care'
    },
    {
      id: 'driver',
      title: 'Driver Portal',
      description: 'Manage deliveries, view routes, and update order status.',
      icon: <Truck className="w-8 h-8 text-brand-primary" />,
      path: '/driver',
      buttonText: 'View Delivery Routes'
    },
    {
      id: 'pharmacy',
      title: 'Pharmacy Portal',
      description: 'Manage inventory, process prescriptions, and handle orders.',
      icon: <Store className="w-8 h-8 text-brand-primary" />,
      path: '/pharmacy',
      buttonText: 'Manage Inventory'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-b from-blue-100/40 to-transparent rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
      
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24 relative z-10">
        
        {/* Headings */}
        <div className="text-center mb-16 space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-100 text-brand-primary text-xs font-semibold tracking-wide uppercase mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <Activity className="w-3.5 h-3.5" />
                Trusted Medical Infrastructure
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
                Choose Your <span className="text-brand-primary">Portal</span>
            </h1>
            <p className="text-lg text-slate-500 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
                Secure access to MedGuardian's quantum-encrypted network. Select your role to proceed to your dashboard.
            </p>
        </div>

        {/* Portal Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-300">
          {portals.map((portal) => (
            <div 
              key={portal.id}
              onClick={() => navigate(portal.path)}
              className="group bg-white rounded-[24px] p-8 shadow-sm border border-gray-100 hover:shadow-xl hover:shadow-blue-500/5 hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col h-full relative overflow-hidden"
            >
              {/* Card Hover Gradient */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-blue-50/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-primary transition-colors duration-300 relative z-10">
                <div className="group-hover:text-white transition-colors duration-300">
                  {portal.icon}
                </div>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-brand-primary transition-colors duration-300 relative z-10">
                {portal.title}
              </h2>
              
              <p className="text-gray-500 mb-8 leading-relaxed relative z-10 flex-grow">
                {portal.description}
              </p>
              
              <div className="relative z-10 mt-auto">
                <Button fullWidth className="group-hover:bg-brand-primary">
                  {portal.buttonText}
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          ))}
        </div>

      </main>

      <DrAIChat />
    </div>
  );
};

export default LandingPage;