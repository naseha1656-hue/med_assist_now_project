import React from 'react';
import { Layers, User, Settings, Bell } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo Section */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
            <Layers className="w-6 h-6 text-brand-primary" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold text-gray-900 leading-none">MedGuardian</span>
            <span className="text-xs font-medium text-gray-400 tracking-wider mt-1">QUANTUM CARE</span>
          </div>
        </Link>

        {/* Right Actions */}
        <div className="flex items-center gap-2 md:gap-4">
          <button className="p-2 text-gray-400 hover:text-brand-primary hover:bg-blue-50 rounded-full transition-all">
            <Bell className="w-5 h-5" />
          </button>
          <button className="p-2 text-gray-400 hover:text-brand-primary hover:bg-blue-50 rounded-full transition-all">
            <Settings className="w-5 h-5" />
          </button>
          <div className="w-px h-6 bg-gray-200 mx-2 hidden md:block"></div>
          <button className="flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full hover:bg-gray-50 transition-all border border-transparent hover:border-gray-200">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-100 to-blue-50 flex items-center justify-center text-brand-primary font-bold text-sm">
              JD
            </div>
            <span className="text-sm font-medium text-gray-700 hidden md:block">John Doe</span>
          </button>
        </div>
      </div>
    </header>
  );
};